import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class RowsColumnsTranspositionCryptoSystem {

    // private static int[][] process(String key, String line) {
    // int numChars = line.replaceAll("\\s+", "").length();
    // String[] key1 = key.split(" ");
    // int[][] result = new int[key1.length][2];

    // for (int i = 0; i < key1.length; i++) {
    // result[i][0] = Integer.parseInt(key1[i]);
    // result[i][1] = 0;
    // }

    // for (int i = 0; i < (numChars % key1.length); i++) {
    // result[i][1] = 1;
    // }

    // return result;
    // }

    public static String generateKeyFromSeed(int seed, int length) {

        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= length; i++) {
            numbers.add(i);
        }

        Collections.shuffle(numbers, new Random(seed));

        String key = "";
        for (int i = 0; i < numbers.size(); i++) {
            if (i > 0) {
                key += " ";
            }
            key += numbers.get(i);
        }

        return key;
    }

    public static String encrypt(String key, String line, boolean filer) {
        line = line.replaceAll("\\s+", "").toUpperCase();
        String[] ky = key.split(" ");
        int rows = line.length() / ky.length + (line.length() % ky.length > 0 ? 1 : 0);

        char[][] matrix = new char[ky.length][rows];
        int index = 0;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < ky.length; j++) {
                if (index < line.length()) {
                    matrix[j][i] = line.charAt(index++);
                } else if (filer && index >= line.length()) {
                    matrix[j][i] = (char) (91 - (ky.length - j));
                    index++;
                } else if (!filer && index >= line.length()) {
                    matrix[j][i] = '*';
                    index++;
                }
            }
        }

        String result = "";

        for (int i = 0; i < ky.length; i++) {
            int ind = 0;
            for (int j = 0; j < ky.length; j++) {
                if (ky[j].equals(i + 1 + "")) {
                    ind = j;
                    break;
                }
            }
            for (int k = 0; k < rows; k++) {
                char cc = matrix[ind][k];
                if (cc != '*') {
                    result += cc;
                }
            }
        }

        return result;
    }

    public static String encryptWithSeed(int seed, int length, String line, boolean filer) {
        String key = generateKeyFromSeed(seed, length);
        return encrypt(key, line, filer);
    }

    public static String decrypt(String key, String line) {
        line = line.replaceAll("\\s+", "").toUpperCase();
        String[] ky = key.split(" ");
        int totalChars = line.length();
        int numColumns = ky.length;

        int numRows = (totalChars + numColumns - 1) / numColumns;

        char[][] plainText = new char[numColumns][numRows];

        int[] charsPerColumn = new int[numColumns];
        int baseChars = totalChars / numColumns;
        int extraChars = totalChars % numColumns;

        for (int i = 0; i < numColumns; i++) {
            charsPerColumn[i] = baseChars;
            if (i < extraChars) {
                charsPerColumn[i]++;
            }
        }

        int index = 0;
        for (int keyOrder = 1; keyOrder <= numColumns; keyOrder++) {
            int col = -1;
            for (int j = 0; j < numColumns; j++) {
                if (Integer.parseInt(ky[j]) == keyOrder) {
                    col = j;
                    break;
                }
            }

            for (int row = 0; row < charsPerColumn[col]; row++) {
                if (index < totalChars) {
                    plainText[col][row] = line.charAt(index++);
                }
            }
        }

        String result = "";
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numColumns; col++) {
                if (row < charsPerColumn[col]) {
                    result += plainText[col][row];
                }
            }
        }

        return result;
    }

    public static String decryptWithSeed(int seed, int length, String line) {
        String key = generateKeyFromSeed(seed, length);
        return decrypt(key, line);
    }

    public static void writeToFile(String path, String str) {
        try (PrintWriter writer = new PrintWriter(path)) {
            writer.write(str);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }

    }

    public static void encryptFile(String key, String filePath, boolean filer) {
        File file = new File(filePath);
        try (Scanner scanner = new Scanner(file)) {
            String encryption = "";
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                encryption += encrypt(key, line, filer) + "\n";
            }
            writeToFile("encryption_" + file.getName(), encryption);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }
    }

    public static void decryptFile(String key, String filePath) {
        File file = new File(filePath);
        try (Scanner scanner = new Scanner(file)) {
            String decryption = "";
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                decryption += decrypt(key, line) + "\n";
            }
            writeToFile("decryption_" + file.getName(), decryption);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }
    }

}