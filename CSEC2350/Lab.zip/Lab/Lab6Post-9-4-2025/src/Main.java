public class Main {

    public static void main(String[] args) {
        // System.out.println(RowsColumnsTranspositionCryptoSystem.encrypt("3 1 5 6 2
        // 4", "Security and Cryptography", true));
        // System.out.println(RowsColumnsTranspositionCryptoSystem.encrypt("3 1 5 6 2
        // 4", "Security and Cryptography", false));

        // System.out.println(RowsColumnsTranspositionCryptoSystem.decrypt("3 1 5 6 2
        // 4", "EYYARDOYSTRRICGZCAPPUNTH"));
        // System.out.println(RowsColumnsTranspositionCryptoSystem.decrypt("3 1 5 6 2
        // 4", "EYYARDOYSTRRICGCAPPUNTH"));

        // RowsColumnsTranspositionCryptoSystem.encryptFile("3 1 5 6 2 4", "test.txt",
        // false);
        // RowsColumnsTranspositionCryptoSystem.decryptFile("3 1 5 6 2 4",
        // "encryption_test.txt");

        // for (int i = 0; i < 100; i++) {
        // String key = RowsColumnsTranspositionCryptoSystem.generateKeyFromSeed(3, 10);
        // String encrypted = RowsColumnsTranspositionCryptoSystem.encryptWithSeed(3,
        // 10, "Security and Cryptography",
        // true);
        // String encryptedWithFiler =
        // RowsColumnsTranspositionCryptoSystem.encryptWithSeed(3, 10,
        // "Security and Cryptography", false);

        // String decrypted = RowsColumnsTranspositionCryptoSystem.decryptWithSeed(3,
        // 10, encrypted);
        // String decryptedWithFiler =
        // RowsColumnsTranspositionCryptoSystem.decryptWithSeed(3, 10,
        // encryptedWithFiler);
        // System.out.println("Key: " + key);
        // System.out.println("Encrypted: " + encrypted);
        // System.out.println("Decrypted: " + decrypted);
        // System.out.println("Encrypted with Filer: " + encryptedWithFiler);
        // System.out.println("Decrypted with Filer: " + decryptedWithFiler);
        // System.out.println("\n");
        // // }

        RowsColumnsTranspositionCryptoSystem.encryptFile("test.txt",
                RowsColumnsTranspositionCryptoSystem.generateKeyFromSeed(5, 3), true);
    }
}
