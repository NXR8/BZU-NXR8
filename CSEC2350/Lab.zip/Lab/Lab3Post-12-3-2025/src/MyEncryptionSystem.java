
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class MyEncryptionSystem {

    public static int brakeEncryption(String[][] str) {
        char maxRepeat = (str[26][0]).charAt(0);
        int key = MyMath.mod(maxRepeat - 'E', 26);
        return key;
    }

    public static String encryption(String text, int key) {
        String encrypted = "";
        char[] cs = text.toUpperCase().toCharArray();
        for (char c : cs) {
            if (("" + c).matches("[A-Z]")) {
                encrypted += (char) (MyMath.mod(c - 65 + key, 26) + 65);
            } else {
                encrypted += c;
            }
        }
        return encrypted;
    }

    public static String decryption(String text, int key) {
        String decrypted = "";
        char[] cs = text.toLowerCase().toCharArray();
        for (char c : cs) {
            if (("" + c).matches("[a-z]")) {
                decrypted += (char) (MyMath.mod(c - 97 - key, 26) + 97);
            } else {
                decrypted += c;
            }
        }
        return decrypted;
    }

    public static void encryptFile(String path, int key) {

        try (Scanner scanner = new Scanner(new File(path))) {
            String encryption = "";
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                encryption += encryption(line, key) + "\n";
            }
            writeToFile("encryption.txt", encryption);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }

    }

    public static void decryptFile(String path, int key) {

        try (Scanner scanner = new Scanner(new File(path))) {
            String decryption = "";
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                decryption += decryption(line, key) + "\n";
            }
            writeToFile("decryption.txt", decryption);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }

    }

    public static void writeToFile(String path, String str) {
        try (PrintWriter writer = new PrintWriter(path)) {
            writer.write(str);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }

    }

}
