import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TextAnalyzer {
    private static File file;

    public TextAnalyzer(String path) {
        file = new File(path);
    }

    // Count number of line
    public int countNumLine() throws FileNotFoundException {
        int numLine = 0;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                sc.nextLine();
                numLine++;
            }
        }
        return numLine;
    }

    // Count word
    public int countWord() throws FileNotFoundException {
        int numWord = 0;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String[] s = sc.nextLine().trim().split("\\s+");
                if (s[0].isEmpty()) {
                    continue;
                }
                for (String str : s) {
                    if (str.matches("[A-Za-z]")) {
                        numWord++;
                    }
                }
            }
        }
        return numWord;
    }

    // Count word
    public int countParagraph() throws FileNotFoundException {
        int numParagraph = 1;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String[] s = sc.nextLine().trim().split("\\s+");
                if (s[0].isEmpty()) {
                    numParagraph++;
                }
            }
        }
        return numParagraph;
    }

    // Count character
    public int[] countCharacter() throws FileNotFoundException {
        int[] chars = new int[30];

        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                char[] s = sc.nextLine().toCharArray();
                int i;
                for (i = 0; i < s.length; i++) {
                    String str = "";
                    str += s[i];
                    if (str.matches("[A-Za-z]")) {
                        chars[29]++;
                        int ch = (int) str.toUpperCase().toCharArray()[0];
                        chars[ch - 65]++;
                    } else if (str.matches(" ")) {
                        chars[26]++;
                    } else if (str.matches(".")) {
                        chars[27]++;
                    } else if (str.matches(",")) {
                        chars[28]++;
                    }
                }
            }
        }
        return chars;
    }

    // Count percentage of characters
    public String[][] countPercentage(int[] chars) {
        int i;
        double max = 0.0;
        double min = Double.MAX_VALUE;
        String[][] percentage = new String[28][2];

        for (i = 0; i < 26; i++) {
            double percentageChar = ((chars[i] * 100.0) / chars[29]);
            percentage[i][0] = (char) (i + 65) + "";
            percentage[i][1] = ("" + percentageChar);

            if (percentageChar > max) {
                max = percentageChar;
                percentage[26][0] = (char) (i + 65) + "";
                percentage[26][1] = ("" + percentageChar);
            } else if (percentageChar < min) {
                min = percentageChar;
                percentage[27][0] = (char) (i + 65) + "";
                percentage[27][1] = ("" + percentageChar);
            }
        }
        return percentage;
    }

}
