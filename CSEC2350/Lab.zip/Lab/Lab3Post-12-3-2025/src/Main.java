import java.io.FileNotFoundException;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        TextAnalyzer ta = new TextAnalyzer("encryption.txt");
        String[][] percentage = ta.countPercentage(ta.countCharacter());
        int key = MyEncryptionSystem.brakeEncryption(percentage);
        System.out.println(key);
        MyEncryptionSystem.decryptFile("encryption.txt", key);

        // MyEncryptionSystem.decryptFile("encryption.txt",MyEncryptionSystem.brakeEncryption(ta.countPercentage(ta.countCharacter())));

    }
}
