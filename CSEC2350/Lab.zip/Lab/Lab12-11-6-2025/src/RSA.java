class RSA {
    private int p;
    private int q;
    private int n;
    private int phi;
    private int e;
    private int d;
    
    public RSA(int p, int q) {
        this.p = p;
        this.q = q;
        this.n = p * q;
        this.phi = (p - 1) * (q - 1);
        // this.e = setE();
        this.e = 65537;
        this.d = MyMath.modInverse(e, phi);
    }
    
    public int process(int a, int x) {
        return modExp(a, x, n);
    }

    private int modExp(int base, int exponent, int modulus) {
        if (modulus == 1) return 0;
        long result = 1;  // Use long to prevent overflow
        long b = base % modulus;
        while (exponent > 0) {
            if (exponent % 2 == 1) {
                result = (result * b) % modulus;
            }
            exponent = exponent >> 1;
            b = (b * b) % modulus;
        }
        return (int) ((result + modulus) % modulus);  // Ensure positive result
    }

    public int getP() {
        return p;
    }

    public int getQ() {
        return q;
    }

    public int getN() {
        return n;
    }

    public int getPhi() {
        return phi;
    }

    public int getE() {
        return e;
    }

    public int getD() {
        return d;
    }

    public int setE() {
        int e = 2;
        while (MyMath.gcd(e, phi) != 1) {
            e++;
        }
        return e;
    }

    
    
}
