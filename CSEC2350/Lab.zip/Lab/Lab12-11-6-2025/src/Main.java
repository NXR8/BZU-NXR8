public class Main {

    public static void main(String[] args) {

        RSA rsa = new RSA(727, 2027);
        System.out.println("P: " + rsa.getP());
        System.out.println("Q: " + rsa.getQ());
        System.out.println("N: " + rsa.getN());
        System.out.println("Phi: " + rsa.getPhi());
        System.out.println("E: " + rsa.getE());
        System.out.println("D: " + rsa.getD());

        System.out.println();

        System.out.println("Flag1: ");
        String plainText = "FLAG{RSA_1s_Fun_But_Keep_Your_Pr1v4t3_K3ys_S3cur3!}";
        int[] encryptedText = new int[plainText.length()];
        for (int i = 0; i < plainText.length(); i++) {
            encryptedText[i] = rsa.process(plainText.charAt(i), rsa.getE());
        }
        for (int i = 0; i < encryptedText.length; i++) {
            System.out.print(encryptedText[i] + " ");
        }
        System.out.println();
        int[] decryptedText = new int[plainText.length()];
        for (int i = 0; i < plainText.length(); i++) {
            decryptedText[i] = rsa.process(encryptedText[i], rsa.getD());
        }
        for (int i = 0; i < decryptedText.length; i++) {
            System.out.print((char) decryptedText[i]);
        }
        System.out.println("\n\n");


        System.out.println("Flag2: ");
        String plainText2 = "FLAG{p=727_q=2027_n=1473629_e=5_d=1176701}";
        int[] encryptedText2 = new int[plainText2.length()];
        for (int i = 0; i < plainText2.length(); i++) {
            encryptedText2[i] = rsa.process(plainText2.charAt(i), rsa.getE());
        }
        for (int i = 0; i < encryptedText2.length; i++) {
            System.out.print(encryptedText2[i] + " ");
        }
        System.out.println();
        int[] decryptedText2 = new int[plainText2.length()];
        for (int i = 0; i < plainText2.length(); i++) {
            decryptedText2[i] = rsa.process(encryptedText2[i], rsa.getD());
        }
        for (int i = 0; i < decryptedText2.length; i++) {
            System.out.print((char) decryptedText2[i]);
        }
        System.out.println("\n\n");

        System.out.println("Flag3: ");
        String plainText3 = "FLAG{H1dd3n_1n_Th3_M0dul4r_3xp0n3nt14t10n}";
        int[] encryptedText3 = new int[plainText3.length()];
        for (int i = 0; i < plainText3.length(); i++) {
            encryptedText3[i] = rsa.process(plainText3.charAt(i), rsa.getE());
        }
        for (int i = 0; i < encryptedText3.length; i++) {
            System.out.print(encryptedText3[i] + " ");
        }
        System.out.println();
        int[] decryptedText3 = new int[plainText3.length()];
        for (int i = 0; i < plainText3.length(); i++) {
            decryptedText3[i] = rsa.process(encryptedText3[i], rsa.getD());
        }
        for (int i = 0; i < decryptedText3.length; i++) {
            System.out.print((char) decryptedText3[i]);
        }
        System.out.println();
    }
}
