
public class CFB {
    private String key;
    private String iv;
    
    
    CFB(String key, String iv){
        this.key = key;
        this.iv = iv;
    }

    // Helper function to perform XOR operation
    private String xor(String a, String b){
        // Binary XOR operation
        String result = "";
        for(int i = 0; i < a.length(); i++){
            result += (a.charAt(i) == b.charAt(i)) ? '0' : '1';
        }
        return result;
    }

    public String encrypt(String input){
        String result = "";
        int sub = 0;
        while (iv.length() < input.length()){
            
            result += encrypt(input.substring(0, input.length()/2));
            sub += input.length()/2;
            input = input.substring(input.length()/2);

        }
        String encrypted = xor(iv, key);
        result += xor(input, encrypted.substring(0, input.length()));
        iv = encrypted.substring(input.length()) + result.substring(sub);
        System.out.println("IV: " + iv);
        return result;
    }

    public String decrypt(String input){
        String result = "";
        int sub = 0;
        while (iv.length() < input.length()){
            
            result += decrypt(input.substring(0, input.length()/2));
            sub += input.length()/2;
            input = input.substring(input.length()/2);

        }
        String decrypted = xor(iv, key);
        result += xor(input, decrypted.substring(0, input.length()));
        iv = decrypted.substring(input.length()) + input.substring(sub);
        System.out.println("IV: " + iv);
        return result;
    }

    private static String AsciiToBinary(String input){
        String result = "";
        for(int i = 0; i < input.length(); i++){
            result += String.format("%8s", Integer.toBinaryString(input.charAt(i))).replace(' ', '0');
        }
        return result;
    }

    public static void main(String[] args) {
        // CFB cfb = new CFB(AsciiToBinary("Key for test CFB"), AsciiToBinary("IV for test CFB ")); // 128 bit Key and IV

        // String receve1 = "Hi";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve1)));

        // String receve2 = ",";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve2)));

        // String receve3 = " my name i";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve3)));

        // String receve4 = "s Nezar Jamal Babeka";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve4)));

        // String receve5 = ", i am a student of BZU";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve5)));

        // String receve6 = " of Computer Science and Engineering";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve6)));

        // String receve7 = " Department ";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve7)));

        // String receve8 = "and I am study cyber security";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve8)));

        // String receve9 = " at BZU";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve9)));

        // String receve10 = ".";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve10)));

        /////////////////////////////////////////////////////////
        CFB testEnc = new CFB("1100", "0101");
        System.out.println(testEnc.encrypt("00"));
        System.out.println(testEnc.encrypt("11"));

        CFB testDec = new CFB("1100", "0101");
        System.out.println(testDec.decrypt("10"));
        System.out.println(testDec.decrypt("01"));


    }



    
    
}