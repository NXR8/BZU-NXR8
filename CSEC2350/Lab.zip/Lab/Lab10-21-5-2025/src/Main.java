public class Main {

    public static void main(String[] args) {
        // CFB cfb = new CFB(AsciiToBinary("Key for test CFB"), AsciiToBinary("IV for test CFB ")); // 128 bit Key and IV

        // String receve1 = "Hi";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve1)));

        // String receve2 = ",";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve2)));

        // String receve3 = " my name i";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve3)));

        // String receve4 = "s Nezar Jamal Babeka";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve4)));

        // String receve5 = ", i am a student of BZU";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve5)));

        // String receve6 = " of Computer Science and Engineering";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve6)));

        // String receve7 = " Department ";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve7)));

        // String receve8 = "and I am study cyber security";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve8)));

        // String receve9 = " at BZU";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve9)));

        // String receve10 = ".";
        // System.out.println(cfb.encrypt(AsciiToBinary(receve10)));

        /////////////////////////////////////////////////////////
        CFB test1 = new CFB("1100", "0101");
        System.out.println(test1.encrypt("00"));
        System.out.println(test1.encrypt("11"));

        CFB test11 = new CFB("1100", "0101");
        System.out.println(test11.decrypt("10"));
        System.out.println(test11.decrypt("01"));




    }

    private static String AsciiToBinary(String input){
        String result = "";
        for(int i = 0; i < input.length(); i++){
            result += String.format("%8s", Integer.toBinaryString(input.charAt(i))).replace(' ', '0');
        }
        return result;
    }
}
