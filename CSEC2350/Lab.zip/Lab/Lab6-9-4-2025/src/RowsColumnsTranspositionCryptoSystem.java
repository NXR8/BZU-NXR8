public class RowsColumnsTranspositionCryptoSystem {

    private static int[][] process(String key, String line) {
        int numChars = line.replaceAll("\\s+", "").length();
        String[] key1 = key.split(" ");
        int [][] result = new int[key1.length][2];

        for (int i = 0; i < key1.length; i++) {
            result[i][0] = Integer.parseInt(key1[i]);
            result[i][1] = 0;
        }

        for (int i = 0; i < (numChars % key1.length); i++){
            result[i][1] = 1;
        }
        
        return result;
    }

    public static String encrypt(String key, String line, boolean filer) {
        line = line.replaceAll("\\s+", "").toUpperCase();
        String[] ky = key.split(" ");
        int rows = line.length() / ky.length + (line.length() % ky.length > 0 ? 1 : 0);
        
        char[][] matrix = new char[ky.length][rows];
        int index = 0;

        for (int i = 0; i < rows; i++){
            for (int j = 0; j < ky.length; j++){
                if (index < line.length()){
                    matrix[j][i] = line.charAt(index++);
                } else if (filer && index >= line.length()){
                    matrix[j][i] = (char) (91 - (ky.length - j));
                    index++;
                } else if (!filer && index >= line.length()){
                    matrix[j][i] = '*';
                    index++;
                }
            }
        }

        String result = "";

        for (int i = 0; i < ky.length; i++){
            int ind = 0;
            for (int j = 0; j < ky.length; j++){
                if (ky[j].equals(i+1 + "")){
                    ind = j;
                    break;
                }
            }
            for (int k = 0; k < rows; k++){
                char cc = matrix[ind][k];
                if (cc != '*'){
                    result += cc;
                }
            }
        }

        return result;
    }

    // public static String decrypt(String key, String line) {
    //     line = line.replaceAll("\\s+", "").toUpperCase();
    //     String[] ky = key.split(" ");
    //     int rows = line.length() / ky.length + (line.length() % ky.length > 0 ? 1 : 0);
    //     String result = "";
    //     int[][] process = process(key, line);
    //     char[][] plainText = new char[ky.length][rows];

    //     int index = 0;
    //     int loop = 0;
    //     for (int i = 0; i < ky.length; i++){
    //         int ind = 0;
    //         for (int j = 0; j < ky.length; j++){
    //             if (ky[j].equals(i+1 + "")){
    //                 if (process[j][1] == 1){
    //                     loop = rows -1;
    //                 } else {
    //                     loop = rows;
    //                 }
    //                 ind = j;
    //                 break;
    //             }
    //         }
    //         for (int k = 0; k < loop; k++){
    //             plainText[ind][k] = line.charAt(index++);
    //             if (loop == rows - 1 && process[ind][1] == 1){
    //                 plainText[ind][k] = '*';
    //             }
    //         }
    //     }

    //     for (int i = 0; i < rows; i++){
    //         for (int j = 0; j < ky.length; j++){
    //             if (plainText[j][i] != '*'){
    //                 result += plainText[j][i];
    //             }
    //         }
    //     }
        
    //     return result;
    // }

    public static String decrypt(String key, String line) {
        line = line.replaceAll("\\s+", "").toUpperCase();
        String[] ky = key.split(" ");
        int totalChars = line.length();
        int numColumns = ky.length;
        int numRows = (totalChars + numColumns - 1) / numColumns;
        int[][] process = process(key, line);
        char[][] plainText = new char[numColumns][numRows];

        int index = 0;
        
        // Fill the matrix column by column in key order
        for (int keyOrder = 1; keyOrder <= numColumns; keyOrder++) {
            // Find which column corresponds to this key order
            int col = -1;
            for (int j = 0; j < numColumns; j++) {
                if (Integer.parseInt(ky[j]) == keyOrder) {
                    col = j;
                    break;
                }
            }
            
            // Determine how many rows this column should have
            int rowsForThisColumn = numRows;
            if (process[col][1] == 1) {
                rowsForThisColumn = numRows - 1;
            }
            
            // Fill this column
            for (int row = 0; row < rowsForThisColumn; row++) {
                if (index < totalChars) {
                    plainText[col][row] = line.charAt(index++);
                }
            }
        }

        // Read the matrix row by row
        String result = "";
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numColumns; col++) {
                if (row < numRows - 1 || process[col][1] == 0) {
                    if (plainText[col][row] != 0) { // Check if the character was set
                        result += plainText[col][row];
                    }
                }
            }
        }
        
        return result;
    }

}