public class Main {

    public static void main(String[] args) {
        // System.out.println(RowsColumnsTranspositionCryptoSystem.encrypt("3 1 5 6 2
        // 4", "Security and Cryptography", true));
        // System.out.println(RowsColumnsTranspositionCryptoSystem.encrypt("3 1 5 6 2
        // 4", "Security and Cryptography", false));

        String ct = "dneeaiecvdysascnaeyrohc";
        for (int i = 0; i < 20; i++) {
            System.out.println(ct);
            ct = RowsColumnsTranspositionCryptoSystem.encrypt("2 5 1 6 4 7 3", ct, false);
        }
        System.out.println(ct);

    }
}
