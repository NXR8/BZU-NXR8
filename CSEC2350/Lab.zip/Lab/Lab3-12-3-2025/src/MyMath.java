public class MyMath {

    public static int mod(int a, int b) {
        if (a < 0) {
            for (; a < 0; a += b) {
            }
        }
        return a % b;
    }
}



