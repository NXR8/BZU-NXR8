
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

public class MyEncrypt {

    public static char[][] generateDictionary(int seed) {
        // public static char[][] generateDictionary() {
        char[][] dictionary = new char[26][2];
        for (int i = 0; i < 26; i++) {
            dictionary[i][0] = (char) (i + 65);
        }
        Random random = new Random(seed);
        // Random random = new Random();

        for (int i = 0; i < 26; i++) {
            char c = (char) (MyMath.mod(random.nextInt(), 26) + 65);
            for (char[] cs : dictionary) {
                if (cs[1] == c) {
                    j--;
                    break;
                }
            }
            dictionary[i][1] = c;
        }
        return dictionary;
    }

    public static String encrypt(String text, char[][] dictionary) {
        String encrypted = "";
        char[] cs = text.toUpperCase().toCharArray();
        for (char c : cs) {
            if (("" + c).matches("[A-Z]")) {
                encrypted += dictionary[(c - 65)][1];
            } else {
                encrypted += c;
            }
        }
        return encrypted;
    }

    public static String decrypt(String text, char[][] dictionary) {

        String decrypted = "";
        char[] cs = text.toUpperCase().toCharArray();
        for (char c : cs) {
            if (("" + c).matches("[A-Z]")) {
                for (int i = 0; i < 26; i++) {
                    if (dictionary[i][1] == c) {
                        decrypted += dictionary[i][0];
                        break;
                    }
                }
            }
        }
        return decrypted;
    }

    // public static void encryptFile(String path, char[][] dictionarys) throws
    // FileNotFoundException {
    public static void encryptFile(String path) throws FileNotFoundException {
        try (Scanner scanner = new Scanner(new File(path))) {
            int seed = scanner.nextInt();
            String encrypted = "" + seed;
            System.out.println(seed);
            char[][] dictionary = generateDictionary(seed);
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                System.out.println(line);
                encrypted += encrypt(line, dictionary) + "\n";
            }
            writeFile(encrypted, "encrypted.txt");
        }
    }

    public static void writeFile(String text, String path) {
        try (PrintWriter writer = new PrintWriter(path)) {
            writer.write(text);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println(e.getMessage());
        }
    }

    // public static void decryptFile(String path, char[][] dictionarys) throws
    // FileNotFoundException {
    public static void decryptFile(String path) throws FileNotFoundException {
        try (Scanner scanner = new Scanner(new File(path))) {
            int seed = scanner.nextInt();
            String decrypted = "" + seed;
            char[][] dictionary = generateDictionary(seed);

            System.out.println(seed);

            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                System.out.println(line);
                decrypted += decrypt(line, dictionary) + "\n";
            }
            writeFile(decrypted, "decrypted.txt");
        }
    }
}
