import java.io.FileNotFoundException;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        // char[][] dictionaries = MyEncrypt.generateDictionary(3);
        // char[][] dictionaries = MyEncrypt.generateDictionary();
        // for (int i = 0; i < 26; i++){
        // System.out.println(dictionaries[i][0] + " -> " + dictionaries[i][1]);
        // }
        // MyEncrypt.encryptFile("test.txt", dictionaries);
        // MyEncrypt.decryptFile("encrypted.txt", dictionaries);
        // MyEncrypt.decryptFile("encrypted.txt");

        MyEncrypt.encryptFile("test.txt");

    }

}
