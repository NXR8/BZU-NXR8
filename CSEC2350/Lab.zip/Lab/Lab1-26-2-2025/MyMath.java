import java.util.Scanner;

public class MyMath {
    Scanner scanner = new Scanner(System.in);


    public int mod(int a, int b) {
        if (a < 0) {
            for (; a < 0; a += b) {
            }
        }
        return a % b;
    }


    private int[][] readMatrix(int n){

        int [][] matrix1 = new int[4][4];
        System.out.println("Enter matrix" + n + ": ");
        for (int i = 0; i < 4; i++) {
            System.out.print("Row " + (i + 1) + ": ");
            String line1 = scanner.nextLine();
            String[] elements1 = line1.split(" ");
            for (int j = 0; j < 4; j++) {
                matrix1[i][j] = Integer.parseInt(elements1[j]);
            }
        }
        return matrix1;
    }

    public void addMatrix() {
        int [][] matrix1 = readMatrix(1);
        int [][] matrix2 = readMatrix(2);


        int [][] result = new int[4][4];

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                result[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }

        printMatrix(result);
    }

    private void printMatrix(int[][] matrix) {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }


    public String reverseString(String s){

        String reversed = "";
        for (int i = s.length() - 1; i >= 0; --i) {
            reversed += s.charAt(i);
        }
        return reversed;
    }

    public void encrypt(String s){
        for (int i = 0; i < s.length(); i++){
            int charCode = (int)s.charAt(i) - 31;
            System.out.print((char)charCode);
        }
        System.out.println();

    }

    public void decrypt(String s){
        for (int i = 0; i < s.length(); i++){
            int charCode = (int)s.charAt(i) + 31;
            System.out.print((char)charCode);
        }
        System.out.println();
    }
}



