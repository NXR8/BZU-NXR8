public class Driver {
    public static void main(String[] args) {
        MyMath myMath = new MyMath();
        System.out.println(myMath.mod(10, 3)); // --> 1
        myMath.addMatrix();
        System.out.println(myMath.reverseString("Hello")); // --> olleH
        myMath.encrypt("abc"); // --> BCD
        myMath.decrypt("BCD"); // --> abc


    }
}
