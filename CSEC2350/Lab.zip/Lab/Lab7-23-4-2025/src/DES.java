public class DES {

    public static void subKeys(String key) {
        byte[] keyBytes = key.getBytes();
        System.out.println(keyBytes.toString());
    }
}
