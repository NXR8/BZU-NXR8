import java.io.FileNotFoundException;

public class Driver {
    public static void main(String[] args) throws FileNotFoundException {
        TextAnalyzer ta = new TextAnalyzer("t.txt");
        // TextAnalyzer ta = new TextAnalyzer("test.txt");
        ta.printNumLine();
        ta.countParagraph();
        ta.countWord();
        ta.countCharacterAndPercentage();
    }
}
