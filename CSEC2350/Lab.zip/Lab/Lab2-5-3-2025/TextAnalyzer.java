import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TextAnalyzer {
    // private static final File file = new File("test.txt");
    private static File file;

    public TextAnalyzer(String path) {
        file = new File(path);
    }

    // Print number of line
    public void printNumLine() throws FileNotFoundException {
        int numLine = 0;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                sc.nextLine();
                numLine++;
            }
        }
        System.out.println("Number of line is: " + numLine);
    }

    // Count word
    public void countWord() throws FileNotFoundException {
        int numWord = 0;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String[] s = sc.nextLine().trim().split("\\s+");
                if (s[0].isEmpty()) {
                    continue;
                }
                for (String str : s) {
                    if (str.matches("[A-Za-z]")) {
                        numWord++;
                    }
                }
            }
        }
        System.out.println("Number of word is: " + numWord);
    }

    // Count word
    public void countParagraph() throws FileNotFoundException {
        int numParagraph = 1;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String[] s = sc.nextLine().trim().split("\\s+");
                if (s[0].isEmpty()) {
                    numParagraph++;
                }
            }
        }
        System.out.println("Number of paragraph is: " + numParagraph);
    }

    // Count character
    public void countCharacterAndPercentage() throws FileNotFoundException {
        int numCharacter = 0;
        int numSpaces = 0;
        int numPoint = 0;
        int numComa = 0;
        int[] chars = new int[26];

        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                char[] s = sc.nextLine().toCharArray();
                int i;
                for (i = 0; i < s.length; i++) {
                    String str = "";
                    str += s[i];
                    if (str.matches("[A-Za-z]")) {
                        numCharacter++;

                        int ch = (int) str.toUpperCase().toCharArray()[0];
                        chars[ch - 65]++;
                    } else if (str.matches(" ")) {
                        numSpaces++;
                    } else if (str.matches(".")) {
                        numPoint++;
                    } else if (str.matches(",")) {
                        numComa++;
                    }
                }
            }
        }
        System.out.println("Number of characters is: " + numCharacter);
        System.out.println("Number of spaces is: " + numSpaces);
        System.out.println("Number of point is: " + numPoint);
        System.out.println("Number of coma is: " + numComa);
        countPercentage(chars, numCharacter);

    }

    // Percentage of characters
    private void countPercentage(int[] chars, int numCharacter) throws FileNotFoundException {
        int i;
        char isMax = 'a';
        double max = 0.0;
        char isMin = 'a';
        double min = Double.MAX_VALUE;

        for (i = 0; i < chars.length; i++) {
            double percentageChar = ((chars[i] * 100.0) / numCharacter);
            System.out.println("Percentage of " + (char) (i + 65) + " is: " + percentageChar);
            if (percentageChar > max) {
                max = percentageChar;
                isMax = (char) (i + 65);
            }
            if (percentageChar < max) {
                min = percentageChar;
                isMin = (char) (i + 65);
            }
        }
        System.out.println("Max character repeated is '" + isMax + "' and percentage is: " + max);
        System.out.println("Min character repeated is '" + isMin + "' and percentage is: " + min);

    }

}
