public class MyFormatter {

    public static String ASCIIToBin(String str) {
        String bin = "";
        for (int i = 0; i < str.length(); i++) {
            // Convert each character to 8 digits binary
            String binary = String.format("%8s", Integer.toBinaryString(str.charAt(i))).replace(' ', '0');
            bin += binary;
        }
        return bin;
    }

    public static String binToHex(String bin) {
        String hex = "";
        for (int i = 0; i < bin.length(); i += 4) {
            // Convert each 4-bit binary to hex
            hex += Integer.toHexString(Integer.parseInt(bin.substring(i, i + 4), 2));
        }
        return hex;
    }

    public static String binToASCII(String bin) {
        String str = "";
        for (int i = 0; i < bin.length(); i += 8) {
            // Convert each 8-bit binary to ASCII
            str += (char) Integer.parseInt(bin.substring(i, i + 8), 2);
        }
        return str;
    }

    public static String hexToBin(String hex) {
        String bin = "";
        for (int i = 0; i < hex.length(); i++) {
            // Convert each hex to 4 digits binary
            bin += String.format("%4s", Integer.toBinaryString(Integer.parseInt(hex.charAt(i) + "", 16))).replace(' ',
                    '0');
        }
        return bin;
    }

    public static String XOR(String bin1, String bin2) {
        String result = "";
        for (int i = 0; i < bin1.length(); i++) {
            // XOR each bit
            result += (bin1.charAt(i) == bin2.charAt(i)) ? '0' : '1';
        }
        return result;
    }

    public static int hexToDecimal(String hex) {
        return Integer.parseInt(hex, 16);
    }
}