public class Main {

    public static void main(String[] args) {
        String encrypted = AutoKeyCryptoSystem.encryptString(3, "Hello Hi", true);
        String decrypted = AutoKeyCryptoSystem.decryptString(3, encrypted);
        System.out.println("Encrypted: " + encrypted);
        System.out.println("Decrypted: " + decrypted);
        AutoKeyCryptoSystem.encryptFile(3, "test.txt", false); // put false to make it unreadable
        AutoKeyCryptoSystem.decryptFile(3, "encryption.txt");
    }
}
