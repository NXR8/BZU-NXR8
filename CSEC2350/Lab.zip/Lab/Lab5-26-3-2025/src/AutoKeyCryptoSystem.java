import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

public class AutoKeyCryptoSystem {

    private static int generateKey(int seed) {
        Random random = new Random(seed);
        return Math.abs(random.nextInt() % 26);
    }

    private static String encrypt(int key, String message, boolean readable) {
        if (!readable) {
            message = message.toUpperCase().replaceAll("[^A-Z]", "");
        }
        char c;
        String encrypted = "";
        for (int i = 0; i < message.length(); i++) {
            if ((message.charAt(i) < 'A' || message.charAt(i) > 'Z') && (message.charAt(i) < 'a' || message.charAt(i) > 'z')) {
                encrypted += message.charAt(i);
            } else{
                if (message.charAt(i) <= 'Z')
                    c = 'A';
                else
                    c = 'a';
                if (i == 0){
                    encrypted += (char) (MyMath.mod((message.charAt(i) - c + key), 26) + c);
                } else {
                    char e;
                    if (encrypted.charAt(i - 1) <= 'Z')
                        e = 'A';
                    else
                        e = 'a';
                    encrypted += (char) (MyMath.mod(((message.charAt(i) - c) + (message.charAt(i - 1) - e)), 26) + c);
                }
            }
        }
        return encrypted;
    }

    private static String decrypt(int key, String message) {
        char c;
        String decrypted = "";
        for (int i = 0; i < message.length(); i++) {
            if ((message.charAt(i) < 'A' || message.charAt(i) > 'Z') && (message.charAt(i) < 'a' || message.charAt(i) > 'z')) {
                decrypted += message.charAt(i);
            } else{
                if (message.charAt(i) <= 'Z')
                    c = 'A';
                else
                    c = 'a';
                if (i == 0){
                    decrypted += (char) (MyMath.mod(((message.charAt(i) - c) - key), 26) + c);
                } else {
                    char d;
                    if (decrypted.charAt(i - 1) <= 'Z')
                        d = 'A';
                    else
                        d = 'a';
                    decrypted += (char) (MyMath.mod(((message.charAt(i) - c) - (decrypted.charAt(i - 1) - d)), 26) + c);
                }
            }
        }
        return decrypted;
    }

    public static String encryptString(int seed, String message, boolean readable) {
        int key = generateKey(seed);
        return encrypt(key, message, readable);
    }

    public static String decryptString(int seed, String message) {
        int key = generateKey(seed);
        return decrypt(key, message);
    }

    public static void writeToFile(String path, String str) {
        try (PrintWriter writer = new PrintWriter(path)) {
            writer.write(str);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }

    }

    public static void encryptFile(int seed, String filePath, boolean readable) {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            String encryption = "";
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                encryption += encryptString(seed, line, readable) + "\n";
            }
            writeToFile("encryption.txt", encryption);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }
    }

    public static void decryptFile(int seed, String filePath) {
        try (Scanner scanner = new Scanner(new File(filePath))) {
            String decryption = "";
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                decryption += decryptString(seed, line) + "\n";
            }
            writeToFile("decryption.txt", decryption);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }
    }
}