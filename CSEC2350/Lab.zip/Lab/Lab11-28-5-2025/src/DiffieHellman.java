public class DiffieHellman {
    
    private int p, g, x;

    public DiffieHellman(int p, int g, int x) {
        this.p = p;
        this.g = g;
        this.x = x;
    }

    public int generatePublicKey() {
        return (int) (Math.pow(g, x)) % p;
    }

    public int generateSecretKey(int publicKey) {
        return (int) (Math.pow(publicKey, x)) % p;
    }
}
