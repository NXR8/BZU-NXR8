import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        DiffieHellman diffieHellman = new DiffieHellman(23, 7, 5);
        int r1 = diffieHellman.generatePublicKey();
        System.out.println("Public Key: " + r1);
        System.out.print("Enter Public Key of other person: ");
        Scanner scanner = new Scanner(System.in);
        int r2 = scanner.nextInt();
        int secretKey = diffieHellman.generateSecretKey(r2);
        System.out.println("Secret Key: " + secretKey);
        scanner.close();
    }
}
