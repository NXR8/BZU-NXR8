public class MyMath {

    public static int mod(int a, int b) {
        if (a < 0) {
            for (; a < 0; a += b) {
            }
        }
        return a % b;
    }

    public static int gcd(int a, int b) {
        if (a < b) {
            int temp = a;
            a = b;
            b = temp;
        }
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }

    public static int modInverse(int a, int p) {
        a = mod(a, p);

        if (gcd(a, p) != 1) {
            return -1;
        }
        for (int x = 1; x < p; x++)
            if (((a % p) * (x % p)) % p == 1)
                return x;
        return 1;
    }

    public static int[][] inverseMatrix(int[][] matrix) {
        int[][] inverse = new int[2][2];
        int det = matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
        if (det == 0) {
            return null;
        }
        det = modInverse(det, 26);
        if (det == -1)
            return null;

        int[][] adjoint = adjointMatrix(matrix);
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                inverse[i][j] = MyMath.mod(adjoint[i][j] * det, 26);
            }
        }
        return inverse;
    }

    public static int[][] adjointMatrix(int[][] matrix) {
        int[][] adjoint = new int[2][2];
        adjoint[0][0] = matrix[1][1];
        adjoint[0][1] = -matrix[0][1];
        adjoint[1][0] = -matrix[1][0];
        adjoint[1][1] = matrix[0][0];
        return adjoint;
    }

    public static int[] matrixMultiplication(int[][] matrix1, int[] matrix2) {
        int[] result = new int[matrix2.length];
        for (int i = 0; i < matrix2.length; i++) {
            for (int j = 0; j < matrix2.length; j++) {
                result[i] += (matrix1[i][j] * matrix2[j]);
            }
        }
        return result;
    }

}
