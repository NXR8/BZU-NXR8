import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class HillCryptoSystemOld {

    public static int[][] generateKeyMatrix(String key, int[][] substitutionTable) {
        key = key.toUpperCase();
        if (Math.sqrt(key.length()) != (int) Math.sqrt(key.length())) {
            System.out.println("Invalid key length");
            return null;
        }
        int length = (int) Math.sqrt(key.length());
        int[][] keyMatrix = new int[length][length];
        int index = 0;

        for (int i = 0; i < length; i++) {
            for (int j = 0; j < length; j++) {
                keyMatrix[i][j] = substitutionTable[key.charAt(index++) - 'A'][1];
            }
        }
        return keyMatrix;
    }

    public static int[][] dataProcessing(String data, int[][] substitutionTable, int lengthOfBlock) {
        data = data.toUpperCase().trim().replaceAll("[^A-Z]", "");
        if (data.length() % lengthOfBlock != 0) {
            for (int i = 0; i < data.length() % lengthOfBlock; i++) {
                data += 'X';
            }
        }
        int[][] dataMatrix = new int[data.length() / lengthOfBlock][lengthOfBlock];
        int index = 0;

        for (int[] dataMatrix1 : dataMatrix) {
            for (int j = 0; j < lengthOfBlock; j++) {
                dataMatrix1[j] = substitutionTable[data.charAt(index++) - 'A'][1];
            }
        }

        return dataMatrix;
    }

    public static int[] encryption(int[][] keyMatrix, int[] dataMatrix) {
        int[] encryptedMatrix = new int[dataMatrix.length];
        for (int i = 0; i < dataMatrix.length; i++) {
            for (int j = 0; j < dataMatrix.length; j++) {
                encryptedMatrix[i] += (keyMatrix[i][j] * dataMatrix[j]);
            }
        }
        for (int i = 0; i < encryptedMatrix.length; i++) {
            encryptedMatrix[i] = MyMath.mod(encryptedMatrix[i], 26);
        }
        return encryptedMatrix;
    }

    public static int[] decryption(int[][] keyMatrix, int[] encryptedMatrix) {
        int[][] inverseKeyMatrix = MyMath.inverseMatrix(keyMatrix);
        if (inverseKeyMatrix == null)
            return null;
        int[] decryptedMatrix = new int[encryptedMatrix.length];
        for (int i = 0; i < encryptedMatrix.length; i++) {
            for (int j = 0; j < encryptedMatrix.length; j++) {
                decryptedMatrix[i] += (inverseKeyMatrix[i][j] * encryptedMatrix[j]);
            }
        }
        for (int i = 0; i < decryptedMatrix.length; i++) {
            decryptedMatrix[i] = MyMath.mod(decryptedMatrix[i], 26);
        }
        return decryptedMatrix;
    }

    public static String encryptString(String data, String key, int[][] substitutionTable) {
        String result = "";

        int[][] keyMatrix = generateKeyMatrix(key, substitutionTable);
        int[][] dataMatrix = dataProcessing(data, substitutionTable, (int) Math.sqrt(key.length()));
        for (int[] dataMatrix1 : dataMatrix) {
            int[] encryptedMatrix = encryption(keyMatrix, dataMatrix1);
            result += (String.valueOf((char) (encryptedMatrix[0] + (int) 'A'))
                    + (char) (encryptedMatrix[1] + (int) 'A'));
        }
        return result;
    }

    public static String decryptString(String data, String key, int[][] substitutionTable) {
        String result = "";

        int[][] keyMatrix = generateKeyMatrix(key, substitutionTable);
        int[][] dataMatrix = dataProcessing(data, substitutionTable, (int) Math.sqrt(key.length()));
        for (int[] dataMatrix1 : dataMatrix) {
            int[] decryptedMatrix = decryption(keyMatrix, dataMatrix1);
            if (decryptedMatrix == null)
                return null;

            result += (String.valueOf((char) (decryptedMatrix[0] + (int) 'A'))
                    + (char) (decryptedMatrix[1] + (int) 'A'));
        }
        return result;
    }

    public static void encryptFile(String path, String key, int[][] substitutionTable) {

        try (Scanner scanner = new Scanner(new File(path))) {
            String encryption = "";
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                encryption += encryptString(line, key, substitutionTable) + "\n";
            }
            writeToFile("encryption.txt", encryption);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }

    }

    public static void decryptFile(String path, String key, int[][] substitutionTable) {

        try (Scanner scanner = new Scanner(new File(path))) {
            String decryption = "";
            while (scanner.hasNext()) {
                String line = scanner.nextLine();
                String decryptedString = decryptString(line, key, substitutionTable);
                if (decryptedString == null) {
                    decryption = "The key \"" + key.toUpperCase() + "\" is not available.";
                    break;
                }
                decryption += decryptedString + "\n";
            }
            writeToFile("decryption.txt", decryption);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }

    }

    public static void writeToFile(String path, String str) {
        try (PrintWriter writer = new PrintWriter(path)) {
            writer.write(str);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
        }

    }

}