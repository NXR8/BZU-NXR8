public class Main {

    public static void main(String[] args) {
        // int[][] substitutionTable = new int[36][2];
        // for (int i = 0; i < 26; i++) {
        //     substitutionTable[i][0] = i + 'A';
        //     substitutionTable[i][1] = MyMath.mod(i + 0, 26);
        // }
        // for (int i = 26; i < 36; i++) {
        //     substitutionTable[i][0] = i - 26 + '0';
        //     substitutionTable[i][1] = i;
        // }

        int[][] substitutionTable2 = new int[61][2];
        for (int i = 32; i < 91; i++) {
            substitutionTable2[i - 32][0] = i;
            substitutionTable2[i - 32][1] = i - 32;
        }
        substitutionTable2[59][0] = '{';
        substitutionTable2[59][1] = 59;
        substitutionTable2[60][0] = '}';
        substitutionTable2[60][1] = 60;


        // int[][] substitutionTable2 = {{'A', 0}, {'B', 1}, {'C', 2}, {'D', 3}, {'E', 4}, {'F', 5}, {'G', 6}, {'H', 7}, {'I', 8}, {'J', 9}, {'K', 10}, {'L', 11}, {'M', 12}, {'N', 13}, {'O', 14}, {'P', 15}, {'Q', 16}, {'R', 17}, {'S', 18}, {'T', 19}, {'U', 20}, {'V', 21}, {'W', 22}, {'X', 23}, {'Y', 24}, {'Z', 25}, {'8', 26}, {'1', 27}, {'3', 28}, {'2', 29}, {'7', 30}, {'9', 31}, {'6', 32}, {'4', 33}, {'0', 34}, {'5', 35}};
        // int[][] substitutionTable2 = {{'A', 0}, {'B', 1}, {'C', 2}, {'D', 3}, {'E', 4}, {'F', 5}, {'G', 6}, {'H', 7}, {'I', 8}, {'J', 9}, {'K', 10}, {'L', 11}, {'M', 12}, {'N', 13}, {'O', 14}, {'P', 15}, {'Q', 16}, {'R', 17}, {'S', 18}, {'T', 19}, {'U', 20}, {'V', 21}, {'W', 22}, {'X', 23}, {'Y', 24}, {'Z', 25}, {'8', 26}};

        // Test substitution table
        for (int i = 0; i < substitutionTable2.length; i++) {
            System.out.print("\'" + (char) substitutionTable2[i][0] + "\':" + String.format("%2d", substitutionTable2[i][1]) + "\t");
            if (i % 10 == 9)
                System.out.println();
        }

        System.out.println();

        String key = "NXR8";

        int[][] keyMatrix = HillCryptoSystem.generateKeyMatrix(key, substitutionTable2);
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(keyMatrix[i][j] + " ");
            }
            System.out.println();
        }

        System.out.println();
        String encryptedString = HillCryptoSystem.encryptString("FLAG{Y0U#@R3!AN%INTELL163NT-HAC1<ER}", key, substitutionTable2);
        // String encryptedString = HillCryptoSystem.encryptString("AGHK", key, substitutionTable2); // J8GK
        System.out.println("encryptedString: " + encryptedString);
        System.out.println("decryptedString: " + HillCryptoSystem.decryptString("#<J8RPL{G#)<#Q1I)K++C7!DBI)M<O 7%?PD", key, substitutionTable2));
        System.out.println();

        int[][] iKey = HillCryptoSystem.inverseMatrix(HillCryptoSystem.generateKeyMatrix(key, substitutionTable2), substitutionTable2.length);

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                System.out.print(iKey[i][j] + " ");
            }
            System.out.println();
        }

    }
}
